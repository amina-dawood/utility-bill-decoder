
# WTQ Utility Bill Decoder

An AI-powered assistant that processes electricity bills from K-Electric (KE), LESCO, and IESCO, extracts structured billing data into JSON (Level 1), and answers customer questions in plain language (Level 2).

## Requirements & Setup

- **Runtime:** Python 3.12 (Python 3.11+ supported)

### Environment Setup

```bash
# Create and activate virtual environment
python -m venv .venv
source .venv/bin/activate        # On Windows: .venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Configure environment variables
cp .env.example .env              # On Windows: copy .env.example .env

```

Open `.env` and set your configuration and API key:

```env
MODEL_PROVIDER=openai
MODEL_NAME=gpt-5-mini
API_KEY=your_actual_api_key_here

```

## Running the Pipeline

To execute the end-to-end extraction and Q&A generation pipeline on the test dataset:

```bash
python main.py --bills test/bills --csv test/csv --out output

```

* `--bills`: Directory containing input bill images (`.jpg`, `.png`).
* `--csv`: Directory containing `level1.csv` and `level2.csv` template files.
* `--out`: Target directory where completed `level1.csv` and `level2.csv` will be generated.

### Development Mode (Quick Test)

To run a fast test pass without requiring full template CSV files:

```bash
python main.py --bills test/bills --out dev_out --dev

```

## System Architecture & Workflow

1. **Level 1 Extraction:** Executes a vision model call per bill using few-shot prompt scaffolding (incorporating the KESC_0008 reference standard). Output is sanitized and validated against target schema rules (strict types, YYYY-MM-DD dates, negative sign preservation for credits/subsidies). An automatic validation pass verifies reading differences and item sums against totals, triggering a single self-correction re-read if discrepancies exist.


2. **History Table Extraction:** A dedicated vision pass parses and extracts historical usage and payment tables.
3. **Level 2 Q&A Generation:** Answers all 12 customer queries using the bill image context, Level 1 JSON, and extracted history. Mathematical calculations are formatted as executable expressions (`{{expression}}`) and computed in Python to guarantee exact numeric accuracy.
4. **Resilience & Fallbacks:** Built-in retry and exception-handling logic guarantees that if an individual API call fails, valid fallback rows are generated so no CSV cell is left empty.



## AI Usage

* **Models:** GPT-5 mini (Model ID: `gpt-5-mini`)


* **APIs & Services:** OpenAI API


* **Local OCR:** None (Native vision capabilities used)
* **AI Coding Assistants:** Claude (Anthropic), OpenAI Codex


